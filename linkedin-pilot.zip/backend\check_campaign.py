import asyncio
from motor.motor_asyncio import AsyncIOMotorClient
import os
from datetime import datetime
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

async def check_campaign():
    client = AsyncIOMotorClient(os.environ.get('MONGO_URL', 'mongodb://localhost:27017'))
    db = client[os.environ.get('DB_NAME', 'linkedin_pilot')]
    
    # Get the campaign
    campaign = await db.campaigns.find_one({'id': 'camp_1760964772642'}, {'_id': 0})
    
    if campaign:
        print("\n" + "="*80)
        print("CAMPAIGN DETAILS")
        print("="*80)
        print(f"Name: {campaign.get('name')}")
        print(f"Status: {campaign.get('status')}")
        print(f"Auto-post: {campaign.get('auto_post', False)}")
        print(f"Frequency: {campaign.get('posting_schedule', {}).get('frequency')}")
        print(f"Time slots: {campaign.get('posting_schedule', {}).get('time_slots')}")
        print(f"Last generation: {campaign.get('last_generation_time')}")
        print(f"Next generation: {campaign.get('next_generation_time')}")
        print(f"Total posts: {campaign.get('total_posts', 0)}")
        print("="*80)
        
        # Check AI posts for this campaign
        ai_posts = await db.ai_generated_posts.find(
            {'campaign_id': 'camp_1760964772642'}
        ).sort('created_at', -1).limit(5).to_list(length=5)
        
        print("\nLATEST 5 AI POSTS:")
        print("-"*80)
        for i, post in enumerate(ai_posts, 1):
            print(f"\n[{i}] {post.get('id')}")
            print(f"    Status: {post.get('status')}")
            print(f"    Created: {post.get('created_at')}")
            print(f"    Scheduled for: {post.get('scheduled_for', 'Not scheduled')}")
            print(f"    Content: {post.get('content', '')[:100]}...")
        
        # Check scheduled posts
        scheduled = await db.scheduled_posts.find(
            {'org_id': campaign.get('org_id')}
        ).to_list(length=None)
        
        print(f"\n\nSCHEDULED POSTS: {len(scheduled)}")
        print("-"*80)
        for i, post in enumerate(scheduled, 1):
            print(f"\n[{i}] {post.get('id')}")
            print(f"    Status: {post.get('status')}")
            print(f"    Publish time: {post.get('publish_time')}")
        
    else:
        print("Campaign not found!")
    
    await client.close()

if __name__ == "__main__":
    asyncio.run(check_campaign())
