from fastapi import APIRouter, HTTPException, UploadFile, File, Form
from typing import List, Dict
from datetime import datetime
import os

from ..models.draft import Draft, DraftMode, DraftStatus
from ..adapters.llm_adapter import LLMAdapter
from ..adapters.image_adapter import ImageAdapter
import base64
import io
from PIL import Image, ImageDraw
import random

from pydantic import BaseModel as PydanticBaseModel

class DraftGenerateRequest(PydanticBaseModel):
    org_id: str
    topic: str
    tone: str
    type: str
    created_by: str

class ImageGenerateRequest(PydanticBaseModel):
    prompt: str
    style: str = "professional"
    user_id: str  # Add user_id to fetch API key
    model: str = "dall-e-2"  # Image model to use

router = APIRouter(prefix="/drafts", tags=["drafts"])

def get_db():
    from motor.motor_asyncio import AsyncIOMotorClient
    client = AsyncIOMotorClient(os.environ['MONGO_URL'])
    return client[os.environ['DB_NAME']]

async def get_user_api_key(user_id: str, key_type: str = "any") -> tuple:
    """Get user's API key from settings
    
    Args:
        user_id: User ID to lookup
        key_type: Type of key to prioritize ("google_ai", "openrouter", "openai", or "any")
    
    Returns:
        Tuple of (api_key, provider) or (None, None)
    """
    from cryptography.fernet import Fernet
    import base64
    import hashlib
    
    print(f"[API_KEY] Looking up API key for user: {user_id} (type: {key_type})")
    
    db = get_db()
    settings = await db.user_settings.find_one({"user_id": user_id}, {"_id": 0})
    
    if not settings:
        print(f"   [ERROR] No settings found for user {user_id}")
        return None, None
    
    print(f"   [SUCCESS] Settings found: {list(settings.keys())}")
    
    # Priority order based on key_type
    if key_type == "google_ai" or key_type == "google_ai_studio":
        key_priority = ['google_ai_api_key', 'openrouter_api_key', 'openai_api_key', 'anthropic_api_key']
    elif key_type == "openrouter":
        key_priority = ['openrouter_api_key', 'google_ai_api_key', 'anthropic_api_key', 'openai_api_key']
    elif key_type == "openai":
        key_priority = ['openai_api_key', 'anthropic_api_key', 'openrouter_api_key', 'google_ai_api_key']
    elif key_type == "anthropic":
        key_priority = ['anthropic_api_key', 'openrouter_api_key', 'openai_api_key', 'google_ai_api_key']
    else:  # "any"
        key_priority = ['openai_api_key', 'google_ai_api_key', 'anthropic_api_key', 'openrouter_api_key']
    
    # Try keys in priority order
    api_key_field = None
    provider = None
    for key_field in key_priority:
        if settings.get(key_field):
            api_key_field = key_field
            if key_field == 'google_ai_api_key':
                provider = 'google_ai_studio'
            elif key_field == 'openrouter_api_key':
                provider = 'openrouter'
            elif key_field == 'anthropic_api_key':
                provider = 'anthropic'
            else:
                provider = 'openai'
            print(f"   [SUCCESS] Found {key_field}")
            break
    
    if not api_key_field:
        print(f"   [ERROR] No API key found (checked {key_priority})")
        return None, None
    
    # Decrypt the API key
    try:
        JWT_SECRET = os.environ.get('JWT_SECRET_KEY', 'your-secret-key-change-in-production')
        ENCRYPTION_KEY = base64.urlsafe_b64encode(hashlib.sha256(JWT_SECRET.encode()).digest())
        cipher_suite = Fernet(ENCRYPTION_KEY)
        
        encrypted_key = settings.get(api_key_field, '')
        if encrypted_key:
            decrypted = cipher_suite.decrypt(encrypted_key.encode())
            decrypted_key = decrypted.decode()
            print(f"   [SUCCESS] Decrypted {api_key_field}: {decrypted_key[:8]}...{decrypted_key[-4:]}")
            return decrypted_key, provider
        else:
            print(f"   [ERROR] {api_key_field} field is empty")
    except Exception as e:
        print(f"   [ERROR] Error decrypting API key: {e}")
    
    return None, None


async def get_user_openai_key(user_id: str) -> str:
    """Legacy function for backward compatibility"""
    api_key, _ = await get_user_api_key(user_id, "any")
    return api_key


async def get_user_canva_key(user_id: str) -> str:
    """Get user's Canva API key from settings"""
    from cryptography.fernet import Fernet
    import base64
    import hashlib
    
    print(f"🎨 Looking up Canva key for user: {user_id}")
    
    db = get_db()
    settings = await db.user_settings.find_one({"user_id": user_id}, {"_id": 0})
    
    if not settings:
        print(f"   ❌ No settings found for user {user_id}")
        return None
    
    if not settings.get('canva_api_key'):
        print(f"   ⚠️ No canva_api_key field in settings (using mock mode)")
        return None
    
    # Decrypt the API key
    try:
        JWT_SECRET = os.environ.get('JWT_SECRET_KEY', 'your-secret-key-change-in-production')
        ENCRYPTION_KEY = base64.urlsafe_b64encode(hashlib.sha256(JWT_SECRET.encode()).digest())
        cipher_suite = Fernet(ENCRYPTION_KEY)
        
        encrypted_key = settings.get('canva_api_key', '')
        if encrypted_key:
            decrypted = cipher_suite.decrypt(encrypted_key.encode())
            decrypted_key = decrypted.decode()
            print(f"   ✅ Decrypted Canva key: {decrypted_key[:8]}...{decrypted_key[-4:]}")
            return decrypted_key
        else:
            print(f"   ⚠️ canva_api_key field is empty (using mock mode)")
    except Exception as e:
        print(f"   ❌ Error decrypting Canva key: {e}")
    
    return None

@router.post("", response_model=Draft)
async def create_draft(draft: Draft):
    """Create a new draft"""
    db = get_db()
    draft_dict = draft.model_dump()
    draft_dict['created_at'] = datetime.utcnow().isoformat()
    draft_dict['updated_at'] = datetime.utcnow().isoformat()
    
    await db.drafts.insert_one(draft_dict)
    return draft

@router.post("/generate")
async def generate_draft_content(request: DraftGenerateRequest):
    """Generate draft content using AI for simple topic-based generation"""
    print(f"\n{'='*60}")
    print(f"[DRAFT] /api/drafts/generate called")
    print(f"   User ID: {request.created_by}")
    print(f"   Topic: {request.topic}")
    print(f"   Tone: {request.tone}")
    
    # Multi-provider fallback: ChatGPT 4o → Gemini → Claude → OpenRouter
    providers_to_try = [
        ("openai", "gpt-4o"),
        ("google_ai_studio", "gemini-2.0-flash-exp"),
        ("anthropic", "claude-3-5-sonnet-20241022"),
        ("openrouter", "anthropic/claude-3.5-sonnet")
    ]
    
    content_data = None
    last_error = None
    
    for provider_name, model_name in providers_to_try:
        try:
            print(f"[LLM] Trying provider: {provider_name} with model: {model_name}")
            
            # Get API key for this provider
            user_api_key, provider = await get_user_api_key(request.created_by, provider_name)
            
            if not user_api_key:
                print(f"   [SKIP] No API key found for {provider_name}")
                continue
            
            print(f"   [SUCCESS] API key found for {provider_name}")
            
            # Initialize LLM adapter with the provider's API key
            llm = LLMAdapter(
                api_key=user_api_key,
                provider=provider,
                model=model_name
            )
            
            # Build context
            context = {
                'topic': request.topic,
                'tone': request.tone,
                'goal': 'engagement'
            }
            
            # Generate content
            content_data = await llm.generate_post_content(context, request.type)
            
            print(f"   [SUCCESS] Content generated with {provider_name}!")
            break  # Success! Exit the loop
            
        except Exception as e:
            print(f"   [ERROR] {provider_name} failed: {str(e)}")
            last_error = e
            continue  # Try next provider
    
    # If all providers failed, raise an error
    if content_data is None:
        print(f"[ERROR] All providers failed. Last error: {last_error}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to generate content with all providers. Please add an API key in Settings. Last error: {str(last_error)}"
        )
    
    print(f"{'='*60}\n")
    
    return {
        "content": content_data.get('body', content_data) if isinstance(content_data, dict) else str(content_data),
        "hashtags": content_data.get('hashtags', []) if isinstance(content_data, dict) else [],
        "org_id": request.org_id,
        "type": request.type
    }

@router.post("/generate-image")
async def generate_image_for_draft(request: ImageGenerateRequest):
    """
    Generate image for a draft with multi-tier fallback:
    1. DALL-E 2 (user's OpenAI API key) - Primary
    2. AI Horde (free, crowdsourced) - Fallback
    3. Mock (placeholder) - Last resort
    """
    print(f"\n{'='*60}")
    print(f"[IMAGE] /api/drafts/generate-image called")
    print(f"   User ID: {request.user_id}")
    print(f"   Prompt: {request.prompt}")
    print(f"   Style: {request.style}")
    print(f"   Model: {request.model}")
    
    # Use model from request (sent by frontend dropdown)
    image_model = request.model
    
    # Priority 1: DALL-E (user's OpenAI API key)
    if image_model in ['dall-e-2', 'dall-e-3']:
        user_api_key, provider = await get_user_api_key(request.user_id, "openai")
        
        if user_api_key:
            print(f"[IMAGE] Using DALL-E with user's API key")
            image_adapter = ImageAdapter(
                api_key=user_api_key,
                provider="openai",
                model=image_model
            )
            
            try:
                image_data = await image_adapter.generate_image(request.prompt, request.style)
                print(f"[SUCCESS] DALL-E image generated!")
                print(f"{'='*60}\n")
                
                return {
                    "url": image_data.get('url'),
                    "image_base64": image_data.get('image_base64'),
                    "prompt": image_data.get('prompt'),
                    "model": image_model,
                    "provider": "OpenAI"
                }
            except Exception as e:
                print(f"[WARNING] DALL-E failed: {e}, falling back to AI Horde...")
        else:
            print(f"[WARNING] No OpenAI API key found, falling back to AI Horde...")
    
    # Priority 2: AI Horde (free, crowdsourced)
    if image_model in ['ai_horde', 'dall-e-2', 'dall-e-3']:
        print(f"[IMAGE] Using AI Horde (free, crowdsourced)")
        image_adapter = ImageAdapter(
            api_key="0000000000",
            provider="ai_horde",
            model="stable_diffusion_xl"
        )
        
        try:
            image_data = await image_adapter.generate_image(request.prompt, request.style)
            print(f"[SUCCESS] AI Horde image generated!")
            print(f"{'='*60}\n")
            
            return {
                "url": image_data.get('url'),
                "prompt": image_data.get('prompt'),
                "model": "AI Horde (Stable Diffusion XL)",
                "provider": "AI Horde",
                "cost": "$0.00",
                "wait_time": image_data.get('wait_time', 0),
                "note": f"Free crowdsourced generation completed in {image_data.get('wait_time', 0)} seconds"
            }
        except Exception as e:
            print(f"[ERROR] AI Horde failed: {e}")
            print(f"{'='*60}\n")
            raise HTTPException(
                status_code=500,
                detail=f"Image generation failed. AI Horde error: {str(e)}. Please try again later or add your OpenAI API key in Settings."
            )
    
    # Handle other models (OpenRouter, etc.)
    user_api_key, provider = await get_user_api_key(request.user_id, "openrouter")
    
    if not user_api_key:
        print(f"[ERROR] No API key found for {image_model}")
        raise HTTPException(
            status_code=400,
            detail=f"API key required for {image_model}. Please add your API key in Settings or use DALL-E 2 / AI Horde."
        )
    
    print(f"[IMAGE] Using {image_model} with user's API key")
    
    # Determine provider
    if image_model.startswith('google/'):
        provider = "openrouter"
    elif image_model.startswith('gemini-'):
        provider = "google_ai_studio"
    
    image_adapter = ImageAdapter(
        api_key=user_api_key,
        provider=provider,
        model=image_model
    )
    
    try:
        image_data = await image_adapter.generate_image(request.prompt, request.style)
        print(f"[SUCCESS] Image generated!")
        print(f"{'='*60}\n")
        
        return {
            "url": image_data.get('url'),
            "image_base64": image_data.get('image_base64'),
            "prompt": image_data.get('prompt'),
            "model": image_model,
            "provider": provider
        }
    except Exception as e:
        print(f"[ERROR] Image generation failed: {e}")
        print(f"{'='*60}\n")
        raise HTTPException(status_code=500, detail=f"Image generation failed: {str(e)}")

@router.post("/upload-image")
async def upload_user_image(
    image: UploadFile = File(...),
    org_id: str = Form(...)
):
    """
    Upload user's own image for a post
    Converts to base64 data URL
    """
    print(f"\n{'='*60}")
    print(f"[UPLOAD] /api/drafts/upload-image called")
    print(f"   Org ID: {org_id}")
    print(f"   Filename: {image.filename}")
    print(f"   Content Type: {image.content_type}")
    
    try:
        # Read image file
        contents = await image.read()
        
        # Convert to base64
        import base64
        img_base64 = base64.b64encode(contents).decode()
        data_url = f"data:{image.content_type};base64,{img_base64}"
        
        print(f"[SUCCESS] Image uploaded and converted to base64")
        print(f"   Size: {len(img_base64)} bytes")
        print(f"{'='*60}\n")
        
        return {
            "success": True,
            "url": data_url,
            "filename": image.filename,
            "size": len(contents)
        }
    except Exception as e:
        print(f"[ERROR] Image upload failed: {e}")
        print(f"{'='*60}\n")
        raise HTTPException(status_code=500, detail=f"Image upload failed: {str(e)}")

@router.post("/generate-carousel")
async def generate_carousel_draft(request: DraftGenerateRequest):
    """Generate carousel draft with AI content and images"""
    print(f"\n{'='*60}")
    print(f"🎠 /api/drafts/generate-carousel called")
    print(f"   User ID: {request.created_by}")
    print(f"   Topic: {request.topic}")
    
    # Get user's OpenAI API key
    user_api_key = await get_user_openai_key(request.created_by)
    
    if not user_api_key:
        print(f"❌ No user API key found")
        raise HTTPException(status_code=400, detail="OpenAI API key required. Please add it in Settings.")
    
    llm = LLMAdapter(api_key=user_api_key)
    image_adapter = ImageAdapter(
        api_key=user_api_key,
        provider="openrouter",
        model="google/gemini-2.5-flash-image"
    )
    
    # Generate carousel content
    context = {
        'topic': request.topic,
        'tone': request.tone,
        'num_slides': 5  # Default to 5 slides
    }
    
    carousel_data = await llm.generate_carousel_content(context)
    
    print(f"✅ Carousel content generated: {len(carousel_data.get('slides', []))} slides")
    
    # Generate images for each slide
    slides_with_images = []
    for i, slide in enumerate(carousel_data.get('slides', [])):
        print(f"   Generating image for slide {i+1}...")
        image_prompt = f"{slide['title']}: {slide['content']}"
        image_data = await image_adapter.generate_image(image_prompt, request.tone)
        
        slides_with_images.append({
            "title": slide['title'],
            "content": slide['content'],
            "image_url": image_data.get('url')
        })
    
    print(f"{'='*60}\n")
    
    return {
        "caption": carousel_data.get('caption'),
        "slides": slides_with_images,
        "hashtags": carousel_data.get('hashtags', []),
        "org_id": request.org_id,
        "type": "carousel"
    }

@router.post("/generate-full")
async def generate_full_draft(org_id: str, campaign_id: str, mode: str, author_id: str, context: Dict = {}):
    """Generate draft content using AI"""
    llm = LLMAdapter()
    content = await llm.generate_post_content(context, mode)
    
    # Create draft
    draft = Draft(
        org_id=org_id,
        campaign_id=campaign_id,
        author_id=author_id,
        mode=DraftMode(mode),
        content=content
    )
    
    db = get_db()
    draft_dict = draft.model_dump()
    draft_dict['created_at'] = datetime.utcnow().isoformat()
    draft_dict['updated_at'] = datetime.utcnow().isoformat()
    
    await db.drafts.insert_one(draft_dict)
    return draft

@router.get("", response_model=List[Draft])
async def list_drafts(org_id: str):
    """List all drafts for an organization"""
    db = get_db()
    drafts = await db.drafts.find({"org_id": org_id}).to_list(length=100)
    
    for d in drafts:
        if isinstance(d.get('created_at'), str):
            d['created_at'] = datetime.fromisoformat(d['created_at'])
        if isinstance(d.get('updated_at'), str):
            d['updated_at'] = datetime.fromisoformat(d['updated_at'])
    
    return [Draft(**d) for d in drafts]

@router.get("/{draft_id}", response_model=Draft)
async def get_draft(draft_id: str):
    """Get draft by ID"""
    db = get_db()
    draft = await db.drafts.find_one({"id": draft_id}, {"_id": 0})
    
    if not draft:
        raise HTTPException(status_code=404, detail="Draft not found")
    
    if isinstance(draft.get('created_at'), str):
        draft['created_at'] = datetime.fromisoformat(draft['created_at'])
    if isinstance(draft.get('updated_at'), str):
        draft['updated_at'] = datetime.fromisoformat(draft['updated_at'])
    
    return Draft(**draft)

@router.delete("/{draft_id}")
async def delete_draft(draft_id: str):
    """Delete a draft"""
    db = get_db()
    result = await db.drafts.delete_one({"id": draft_id})
    
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Draft not found")
    
    return {"message": "Draft deleted successfully", "id": draft_id}

@router.post("/{draft_id}/chat")
async def chat_edit_draft(draft_id: str, message: str):
    """Edit draft using chat interface"""
    db = get_db()
    draft = await db.drafts.find_one({"id": draft_id}, {"_id": 0})
    
    if not draft:
        raise HTTPException(status_code=404, detail="Draft not found")
    
    # Get current content and history
    current_content = draft['content'].get('body', '')
    history = draft.get('ai_edit_history', [])
    
    # Generate edited content
    llm = LLMAdapter()
    edited_content = await llm.edit_post_with_chat(current_content, message, history)
    
    # Update draft
    history.append({"role": "user", "content": message})
    history.append({"role": "assistant", "content": edited_content})
    
    draft['content']['body'] = edited_content
    draft['ai_edit_history'] = history
    draft['version'] = draft.get('version', 1) + 1
    draft['updated_at'] = datetime.utcnow().isoformat()
    
    await db.drafts.update_one(
        {"id": draft_id},
        {"$set": {
            "content": draft['content'],
            "ai_edit_history": history,
            "version": draft['version'],
            "updated_at": draft['updated_at']
        }}
    )
    
    return {"draft_id": draft_id, "content": draft['content'], "version": draft['version']}

@router.post("/{draft_id}/generate-images")
async def generate_images_for_draft(draft_id: str, provider: str = "openai", style: str = "professional"):
    """Generate images for draft"""
    db = get_db()
    draft = await db.drafts.find_one({"id": draft_id}, {"_id": 0})
    
    if not draft:
        raise HTTPException(status_code=404, detail="Draft not found")
    
    # Generate image
    image_adapter = ImageAdapter()
    prompt = draft['content'].get('body', '')[:200]  # Use first 200 chars as prompt
    image_data = await image_adapter.generate_image(prompt, style)
    
    # Add to draft assets
    assets = draft.get('assets', [])
    assets.append({
        "type": "image",
        "url": image_data['url'],
        "prompt": image_data['prompt'],
        "generated_at": datetime.utcnow().isoformat()
    })
    
    await db.drafts.update_one(
        {"id": draft_id},
        {"$set": {"assets": assets, "updated_at": datetime.utcnow().isoformat()}}
    )
    