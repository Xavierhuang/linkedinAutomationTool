"""
Check Tech Time Savers posts in detail
"""
import asyncio
from motor.motor_asyncio import AsyncIOMotorClient
from dotenv import load_dotenv
import os

load_dotenv()

async def check_posts():
    client = AsyncIOMotorClient(os.environ.get('MONGO_URL', 'mongodb://localhost:27017'))
    db = client[os.environ.get('DB_NAME', 'linkedin_pilot')]
    
    # Get Tech Time Savers campaign ID
    campaign = await db.campaigns.find_one({'name': 'Tech Time Savers'}, {'_id': 0, 'id': 1, 'org_id': 1})
    
    if not campaign:
        print("Campaign not found!")
        return
    
    campaign_id = campaign['id']
    org_id = campaign['org_id']
    
    print(f"\nTech Time Savers Campaign ID: {campaign_id}")
    print(f"Organization ID: {org_id}")
    
    # Get all AI posts for this campaign
    posts = await db.ai_generated_posts.find(
        {'campaign_id': campaign_id}
    ).sort('created_at', -1).to_list(length=10)
    
    print(f"\n{'='*80}")
    print(f"AI POSTS FOR TECH TIME SAVERS ({len(posts)} total)")
    print("="*80)
    
    for i, post in enumerate(posts, 1):
        print(f"\n[{i}] Post ID: {post.get('id')}")
        print(f"    Status: {post.get('status')}")
        print(f"    Created: {post.get('created_at')}")
        print(f"    Scheduled for: {post.get('scheduled_for', 'NOT SCHEDULED')}")
        print(f"    Content: {post.get('content', '')[:80]}...")
    
    # Check if calendar is fetching these
    print(f"\n{'='*80}")
    print("CALENDAR FETCH TEST")
    print("="*80)
    
    # Get approved posts (what calendar should show)
    approved = await db.ai_generated_posts.find({
        'org_id': org_id,
        'status': 'approved'
    }).to_list(length=100)
    
    print(f"\nApproved posts for org: {len(approved)}")
    for post in approved:
        print(f"  - {post.get('id')}: scheduled_for = {post.get('scheduled_for', 'NONE')}")
    
    client.close()

if __name__ == "__main__":
    asyncio.run(check_posts())
