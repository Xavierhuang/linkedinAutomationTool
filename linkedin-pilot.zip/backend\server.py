from fastapi import FastAPI, APIRouter, HTTPException, Depends, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict, EmailStr
from typing import List, Optional
import uuid
from datetime import datetime, timezone, timedelta
from passlib.context import CryptContext
import jwt

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Security
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
security = HTTPBearer()
SECRET_KEY = os.environ.get('JWT_SECRET_KEY', 'your-secret-key-change-in-production')
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24 * 7  # 7 days

# Create the main app without a prefix
app = FastAPI()

# Add CORS middleware FIRST, before any routes
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://localhost:3001", "http://192.168.0.101:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["*"]
)

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")

# Password utilities
def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password):
    return pwd_context.hash(password)

def create_access_token(data: dict):
    to_encode = data.copy()
    expire = datetime.now(timezone.utc) + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

def decode_access_token(token: str):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token has expired")
    except jwt.JWTError:
        raise HTTPException(status_code=401, detail="Could not validate token")

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    token = credentials.credentials
    payload = decode_access_token(token)
    user_id = payload.get("user_id")
    if user_id is None:
        raise HTTPException(status_code=401, detail="Invalid authentication credentials")
    
    user = await db.users.find_one({"id": user_id}, {"_id": 0})
    if user is None:
        raise HTTPException(status_code=401, detail="User not found")
    return user

# Models
class User(BaseModel):
    model_config = ConfigDict(extra="ignore")
    
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    email: EmailStr
    full_name: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class UserCreate(BaseModel):
    email: EmailStr
    password: str
    full_name: str

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: User

class UserResponse(BaseModel):
    user: User

# Routes
@api_router.get("/")
async def root():
    return {"message": "Social Media Scheduler API"}

@api_router.post("/auth/signup", response_model=Token)
async def signup(user_create: UserCreate):
    # Check if user already exists
    existing_user = await db.users.find_one({"email": user_create.email})
    if existing_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    # Create new user
    hashed_password = get_password_hash(user_create.password)
    user = User(
        email=user_create.email,
        full_name=user_create.full_name
    )
    
    user_dict = user.model_dump()
    user_dict['created_at'] = user_dict['created_at'].isoformat()
    user_dict['hashed_password'] = hashed_password
    
    await db.users.insert_one(user_dict)
    
    # Create access token
    access_token = create_access_token(data={"user_id": user.id})
    
    return Token(access_token=access_token, user=user)

@api_router.post("/auth/login", response_model=Token)
async def login(user_login: UserLogin):
    # Find user
    user_dict = await db.users.find_one({"email": user_login.email})
    if not user_dict:
        raise HTTPException(status_code=401, detail="Invalid email or password")
    
    # Verify password
    if not verify_password(user_login.password, user_dict['hashed_password']):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    
    # Parse datetime
    if isinstance(user_dict.get('created_at'), str):
        user_dict['created_at'] = datetime.fromisoformat(user_dict['created_at'])
    
    user = User(**user_dict)
    
    # Create access token
    access_token = create_access_token(data={"user_id": user.id})
    
    return Token(access_token=access_token, user=user)

@api_router.get("/auth/me", response_model=UserResponse)
async def get_me(current_user: dict = Depends(get_current_user)):
    # Parse datetime
    if isinstance(current_user.get('created_at'), str):
        current_user['created_at'] = datetime.fromisoformat(current_user['created_at'])
    
    user = User(**current_user)
    return UserResponse(user=user)

# Include LinkedPilot routes BEFORE including api_router into app
from linkedpilot.routes import (
    org_router,
    campaign_router,
    draft_router,
    scheduled_post_router,
    post_router,
    comment_router,
    linkedin_auth_router,
    settings_router
)
from linkedpilot.routes.ai_content import router as ai_content_router

# Import Canva router
from linkedpilot.routes.canva import router as canva_router

# Import Scheduler router
from linkedpilot.routes.scheduler import router as scheduler_router

# Import User Preferences router
from linkedpilot.routes.user_preferences import router as user_prefs_router

# Import Organization Materials router
from linkedpilot.routes.organization_materials import router as org_materials_router

api_router.include_router(org_router)
api_router.include_router(campaign_router)
api_router.include_router(draft_router)
api_router.include_router(scheduled_post_router)
api_router.include_router(post_router)
api_router.include_router(comment_router)
api_router.include_router(linkedin_auth_router)
api_router.include_router(settings_router)
api_router.include_router(canva_router)
api_router.include_router(ai_content_router)
api_router.include_router(scheduler_router)
api_router.include_router(user_prefs_router)
api_router.include_router(org_materials_router)

# Include the router in the main app
app.include_router(api_router)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("startup")
async def startup_event():
    """Start the background scheduler on app startup"""
    from linkedpilot.scheduler_service import start_scheduler
    import asyncio
    import threading
    
    # Run scheduler startup in background with its own event loop
    def start_scheduler_background():
        try:
            # Small delay to ensure main event loop is ready
            import time
            time.sleep(1)
            
            # Create new event loop for this thread
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            
            # Start scheduler
            start_scheduler()
            
            # Keep the loop running
            loop.run_forever()
        except Exception as e:
            print(f"❌ ERROR: Failed to start scheduler")
            print(f"   {str(e)}")
            print(f"   Server will continue without automated scheduling")
    
    # Start scheduler in a separate thread to avoid blocking
    scheduler_thread = threading.Thread(target=start_scheduler_background, daemon=True)
    scheduler_thread.start()
    
    print("✅ Server startup complete - Scheduler initializing in background...")

@app.on_event("shutdown")
async def shutdown_db_client():
    """Stop the scheduler and close database connection"""
    from linkedpilot.scheduler_service import stop_scheduler
    try:
        stop_scheduler()
    except Exception as e:
        print(f"⚠️  WARNING: Failed to stop scheduler: {e}")
    client.close()