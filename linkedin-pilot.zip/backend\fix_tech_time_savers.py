"""
Fix the Tech Time Savers campaign by updating its created_by field to the correct user_id
"""
import asyncio
from motor.motor_asyncio import AsyncIOMotorClient
from dotenv import load_dotenv
import os

load_dotenv()

async def fix_campaign():
    client = AsyncIOMotorClient(os.environ.get('MONGO_URL', 'mongodb://localhost:27017'))
    db = client[os.environ.get('DB_NAME', 'linkedin_pilot')]
    
    # Get the correct user_id from settings
    settings = await db.user_settings.find_one({}, {"_id": 0, "user_id": 1})
    
    if not settings:
        print("❌ No user settings found!")
        client.close()
        return
    
    correct_user_id = settings.get('user_id')
    print(f"✅ Found correct user_id: {correct_user_id}")
    
    # Update Tech Time Savers campaign
    result = await db.campaigns.update_one(
        {"name": "Tech Time Savers"},
        {"$set": {"created_by": correct_user_id}}
    )
    
    if result.modified_count > 0:
        print(f"✅ Updated Tech Time Savers campaign!")
        print(f"   Changed created_by to: {correct_user_id}")
        print(f"\n🎉 The campaign should now generate content on the next scheduler run!")
    else:
        print("⚠️  No changes made")
    
    # Verify the fix
    campaign = await db.campaigns.find_one({"name": "Tech Time Savers"}, {"_id": 0})
    print(f"\nVerification:")
    print(f"  Campaign created_by: {campaign.get('created_by')}")
    print(f"  Settings user_id: {correct_user_id}")
    print(f"  Match: {'✅ YES' if campaign.get('created_by') == correct_user_id else '❌ NO'}")
    
    client.close()

if __name__ == "__main__":
    asyncio.run(fix_campaign())
