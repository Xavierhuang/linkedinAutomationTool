"""
Background scheduler for automated content generation and posting
"""
import os
import asyncio
import base64
import hashlib
from datetime import datetime, timedelta
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from motor.motor_asyncio import AsyncIOMotorClient
from cryptography.fernet import Fernet
import pytz

from linkedpilot.adapters.ai_content_generator import AIContentGenerator
from linkedpilot.adapters.linkedin_adapter import LinkedInAdapter
from linkedpilot.adapters.image_adapter import ImageAdapter
from linkedpilot.models.campaign import AIGeneratedPostStatus, CampaignStatus

# Global scheduler instance
scheduler = None

def get_db():
    """Get database connection"""
    client = AsyncIOMotorClient(os.environ['MONGO_URL'])
    return client[os.environ['DB_NAME']]

def decrypt_api_key(encrypted_key: str) -> str:
    """Decrypt an API key using Fernet encryption (same as settings.py)"""
    try:
        # Handle None or empty keys
        if not encrypted_key:
            return None
            
        # If already decrypted (doesn't look like Fernet-encrypted), return as-is
        if not encrypted_key.startswith('gAAAAA'):
            return encrypted_key
        
        # Use SAME encryption method as settings.py
        import hashlib
        JWT_SECRET = os.environ.get('JWT_SECRET_KEY', 'your-secret-key-change-in-production')
        ENCRYPTION_KEY = base64.urlsafe_b64encode(hashlib.sha256(JWT_SECRET.encode()).digest())
        cipher_suite = Fernet(ENCRYPTION_KEY)
        
        decrypted = cipher_suite.decrypt(encrypted_key.encode()).decode()
        return decrypted
    except Exception as e:
        print(f"[ERROR] Failed to decrypt API key: {e}")
        return None  # Return None if decryption fails

async def generate_content_for_active_campaigns():
    """
    Generate content for all active campaigns based on their posting schedule
    This runs periodically to ensure campaigns have content ready for posting
    """
    print(f"\n{'='*60}")
    print(f"[AI-CONTENT-GEN] Job Started")
    print(f"   Time: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC")
    print(f"{'='*60}\n")
    
    db = get_db()
    
    try:
        # Get all active campaigns
        campaigns = await db.campaigns.find({
            "status": CampaignStatus.ACTIVE
        }).to_list(length=100)
        
        print(f"[CAMPAIGNS] Found {len(campaigns)} active campaigns")
        
        for campaign in campaigns:
            try:
                campaign_id = campaign.get('id')
                campaign_name = campaign.get('name')
                org_id = campaign.get('org_id')
                
                # Check campaign frequency to determine if it's time to generate
                frequency = campaign.get('posting_schedule', {}).get('frequency', 'weekly')
                last_generation = campaign.get('last_generation_time')
                current_time = datetime.utcnow()
                
                # Map frequency to minutes between generations
                frequency_intervals = {
                    'every_5_min': 5,        # Generate every 5 minutes
                    'every_15_min': 15,      # Generate every 15 minutes
                    'every_30_min': 30,      # Generate every 30 minutes
                    'hourly': 60,            # Generate every hour
                    'twice_daily': 720,      # Generate every 12 hours
                    'daily': 1440,           # Generate every 24 hours
                    '3x_week': 3360,         # Generate every ~2.3 days (weekly/3)
                    '2x_week': 5040,         # Generate every ~3.5 days (weekly/2)
                    'weekly': 10080,         # Generate every 7 days
                    'bi_weekly': 20160       # Generate every 14 days
                }
                interval_minutes = frequency_intervals.get(frequency, 10080)  # Default: weekly
                
                # Check if enough time has passed since last generation
                should_generate = False
                if not last_generation:
                    should_generate = True  # Never generated before
                else:
                    # Parse last generation time
                    if isinstance(last_generation, str):
                        last_gen_time = datetime.fromisoformat(last_generation.replace('Z', '+00:00'))
                    else:
                        last_gen_time = last_generation
                    
                    # Calculate time difference
                    time_diff = (current_time - last_gen_time).total_seconds() / 60  # in minutes
                    should_generate = time_diff >= interval_minutes
                
                print(f"\n[CAMPAIGN] {campaign_name}")
                print(f"   Frequency: {frequency} (every {interval_minutes} minutes)")
                if last_generation:
                    print(f"   Last generated: {last_generation}")
                    print(f"   Time since last: {int(time_diff)} minutes ago")
                else:
                    print(f"   Last generated: Never")
                print(f"   Should generate: {'YES' if should_generate else 'NO (too soon)'}")
                
                # Generate content if it's time
                if should_generate:
                    print(f"   [GEN] Generating new content...")
                    
                    # Get user's API keys from settings (by user_id from campaign)
                    user_id = campaign.get('created_by')
                    settings = await db.user_settings.find_one({"user_id": user_id}, {"_id": 0})
                    
                    if not settings:
                        print(f"   [ERROR] No settings found for user!")
                        continue
                    
                    # Build list of available providers with their API keys (OpenAI first as default)
                    available_providers = []
                    if settings.get('openai_api_key'):
                        available_providers.append(('openai', decrypt_api_key(settings['openai_api_key'])))
                    if settings.get('anthropic_api_key'):
                        available_providers.append(('claude', decrypt_api_key(settings['anthropic_api_key'])))
                    if settings.get('google_ai_api_key'):
                        available_providers.append(('gemini', decrypt_api_key(settings['google_ai_api_key'])))
                    if settings.get('openrouter_api_key'):
                        available_providers.append(('openrouter', decrypt_api_key(settings['openrouter_api_key'])))
                    
                    if not available_providers:
                        print(f"   [ERROR] No API keys configured!")
                        print(f"   Please add at least one API key in Settings > API Keys:")
                        print(f"   - OpenRouter (recommended)")
                        print(f"   - OpenAI (ChatGPT)")
                        print(f"   - Anthropic (Claude)")
                        print(f"   - Google AI Studio (Gemini)")
                        continue
                    
                    # Try each provider until one succeeds
                    result = None
                    last_error = None
                    
                    for provider, api_key in available_providers:
                        try:
                            print(f"   [API] Trying {provider} provider...")
                            
                            generator = AIContentGenerator(
                                api_key=api_key,
                                provider=provider
                            )
                            
                            result = await generator.generate_post_for_campaign(campaign)
                            print(f"   [SUCCESS] Content generated with {provider}!")
                            break  # Success! Exit the loop
                            
                        except Exception as gen_error:
                            print(f"   [ERROR] {provider} failed: {gen_error}")
                            last_error = gen_error
                            continue  # Try next provider
                    
                    # If all providers failed
                    if not result:
                        print(f"   [ERROR] All providers failed!")
                        print(f"   Last error: {last_error}")
                        continue
                    
                    # Generate image if campaign requires it
                    image_url = None
                    if campaign.get('include_images', False):
                        try:
                            print(f"   [IMAGE] Generating image...")
                            
                            # Get image settings
                            image_model = 'dall-e-2'  # Default
                            if settings.get('image_model'):
                                image_model = settings['image_model']
                            
                            # Use content pillar as image prompt
                            image_prompt = f"{result.get('content_pillar', 'Professional LinkedIn post')} - {campaign.get('image_style', 'professional')} style"
                            
                            # Try to get OpenAI key first (for DALL-E), fall back to AI Horde
                            image_api_key = None
                            if settings.get('openai_api_key'):
                                image_api_key = decrypt_api_key(settings['openai_api_key'])
                            
                            image_generator = ImageAdapter(
                                api_key=image_api_key,
                                provider='openai' if image_api_key else 'ai_horde',
                                model=image_model if image_api_key else 'stable_diffusion_xl'
                            )
                            
                            image_result = await image_generator.generate_image(
                                prompt=image_prompt,
                                style=campaign.get('image_style', 'professional')
                            )
                            
                            if image_result and 'url' in image_result:
                                image_url = image_result['url']
                                print(f"   [IMAGE] Generated successfully!")
                            else:
                                print(f"   [IMAGE] Failed to generate")
                        except Exception as img_error:
                            print(f"   [WARNING] Image generation failed: {img_error}")
                    
                    # Check if campaign has auto_post enabled
                    auto_post = campaign.get('auto_post', False)
                    
                    # Create AI-generated post record
                    ai_post = {
                        "id": f"aipost_{int(datetime.utcnow().timestamp()*1000)}",
                        "campaign_id": campaign_id,
                        "org_id": org_id,
                        "content": result['content'],
                        "generation_prompt": result['generation_prompt'],
                        "content_pillar": result.get('content_pillar'),
                        "content_type": result.get('content_type', 'text'),
                        "image_url": image_url,  # Add image if generated
                        "status": AIGeneratedPostStatus.APPROVED.value if auto_post else AIGeneratedPostStatus.PENDING_REVIEW.value,
                        "created_at": datetime.utcnow(),
                        "updated_at": datetime.utcnow()
                    }
                    
                    print(f"   [AUTO-POST] {'ENABLED' if auto_post else 'DISABLED'} - Status: {ai_post['status']}")
                    
                    # Save to database
                    try:
                        await db.ai_generated_posts.insert_one(ai_post)
                        print(f"   [DB] Post saved successfully! ID: {ai_post['id']}")
                    except Exception as db_error:
                        print(f"   [ERROR] Failed to save post to database: {db_error}")
                        print(f"   Post data: {ai_post}")
                        continue  # Skip campaign update if DB save failed
                    
                    # Update campaign: increment post count AND update last generation time
                    await db.campaigns.update_one(
                        {"id": campaign_id},
                        {
                            "$inc": {"total_posts": 1},
                            "$set": {"last_generation_time": current_time.isoformat()}
                        }
                    )
                    
                    print(f"   [SUCCESS] Content generated successfully!")
                    print(f"   Provider: {provider}")
                    print(f"   Next generation: {interval_minutes} minutes from now")
                else:
                    print(f"   [SKIP] Too soon to generate (waiting for {interval_minutes - int(time_diff)} more minutes)")
                    
            except Exception as e:
                print(f"   [ERROR] Error generating content: {e}")
                continue
        
        print(f"\n{'='*60}")
        print(f"[AI-CONTENT-GEN] Job Completed")
        print(f"{'='*60}\n")
        
    except Exception as e:
        print(f"[ERROR] Auto-content generation job failed: {e}")
        print(f"{'='*60}\n")

async def auto_schedule_approved_posts():
    """
    Auto-schedule approved posts to campaign time slots
    This assigns scheduled_for times to approved posts that don't have one yet
    """
    db = get_db()
    
    try:
        # Get all approved posts without a scheduled time
        unscheduled_posts = await db.ai_generated_posts.find({
            "status": AIGeneratedPostStatus.APPROVED,
            "scheduled_for": None
        }).to_list(length=100)
        
        if not unscheduled_posts:
            return
        
        print(f"\n[AUTO-SCHEDULE] Found {len(unscheduled_posts)} unscheduled approved posts")
        
        for post in unscheduled_posts:
            try:
                campaign_id = post.get('campaign_id')
                
                # Get campaign to check time slots
                campaign = await db.campaigns.find_one({"id": campaign_id}, {"_id": 0})
                if not campaign:
                    continue
                
                # Get campaign time slots (in HH:MM format like "09:00", "14:00")
                time_slots = campaign.get('posting_schedule', {}).get('time_slots', ['09:00', '14:00'])
                frequency = campaign.get('posting_schedule', {}).get('frequency', 'daily')
                
                # Get user's timezone preference
                user_id = campaign.get('created_by')
                user_prefs = await db.user_settings.find_one({"user_id": user_id}, {"_id": 0})
                user_timezone = user_prefs.get('timezone') if user_prefs else 'UTC'
                
                print(f"   User timezone: {user_timezone}")
                
                # Get current time in user's timezone
                try:
                    tz = pytz.timezone(user_timezone)
                    current_time_user = datetime.now(tz)
                    current_time_utc = datetime.utcnow()
                    
                    print(f"   Current time (user): {current_time_user.strftime('%Y-%m-%d %H:%M %Z')}")
                    print(f"   Current time (UTC): {current_time_utc.strftime('%Y-%m-%d %H:%M UTC')}")
                    
                    # Get all already scheduled posts for this campaign
                    org_id = post.get('org_id')
                    scheduled_posts = await db.ai_generated_posts.find({
                        "org_id": org_id,
                        "status": AIGeneratedPostStatus.APPROVED.value,
                        "scheduled_for": {"$ne": None}
                    }, {"scheduled_for": 1}).to_list(length=1000)
                    
                    occupied_times = {p['scheduled_for'] for p in scheduled_posts if 'scheduled_for' in p}
                    print(f"   Found {len(occupied_times)} occupied time slots")
                    
                    # Helper function to check if a slot is available
                    def is_slot_available(slot_time_utc):
                        # Check if this exact time is already taken
                        for occupied in occupied_times:
                            # Compare with 1-minute tolerance (in case of slight time differences)
                            if abs((occupied - slot_time_utc).total_seconds()) < 60:
                                return False
                        return True
                    
                    # Try to find next available slot
                    scheduled_time = None
                    days_to_check = 7  # Check up to 7 days ahead
                    
                    for day_offset in range(days_to_check):
                        day_user = current_time_user + timedelta(days=day_offset)
                        
                        for slot in time_slots:
                            hour, minute = map(int, slot.split(':'))
                            
                            # Create time in user's timezone
                            slot_time_user = day_user.replace(hour=hour, minute=minute, second=0, microsecond=0)
                            
                            # Convert to UTC
                            slot_time_utc = slot_time_user.astimezone(pytz.UTC).replace(tzinfo=None)
                            
                            # Check if slot is in the future AND available
                            if slot_time_utc > current_time_utc and is_slot_available(slot_time_utc):
                                scheduled_time = slot_time_utc
                                day_label = "today" if day_offset == 0 else f"in {day_offset} days"
                                print(f"   Next available slot: {slot} {day_label} (user time) = {slot_time_utc.strftime('%Y-%m-%d %H:%M UTC')}")
                                break
                        
                        if scheduled_time:
                            break
                    
                    if not scheduled_time:
                        print(f"   [WARNING] No available slots found in next {days_to_check} days!")
                    
                except Exception as tz_error:
                    print(f"   [WARNING] Timezone conversion failed: {tz_error}, using UTC")
                    # Fallback to UTC if timezone conversion fails
                    current_time_utc = datetime.utcnow()
                    
                    # Get occupied slots
                    org_id = post.get('org_id')
                    scheduled_posts = await db.ai_generated_posts.find({
                        "org_id": org_id,
                        "status": AIGeneratedPostStatus.APPROVED.value,
                        "scheduled_for": {"$ne": None}
                    }, {"scheduled_for": 1}).to_list(length=1000)
                    
                    occupied_times = {p['scheduled_for'] for p in scheduled_posts if 'scheduled_for' in p}
                    
                    def is_slot_available_utc(slot_time_utc):
                        for occupied in occupied_times:
                            if abs((occupied - slot_time_utc).total_seconds()) < 60:
                                return False
                        return True
                    
                    scheduled_time = None
                    for day_offset in range(7):
                        day_utc = current_time_utc + timedelta(days=day_offset)
                        for slot in time_slots:
                            hour, minute = map(int, slot.split(':'))
                            slot_time = day_utc.replace(hour=hour, minute=minute, second=0, microsecond=0)
                            if slot_time > current_time_utc and is_slot_available_utc(slot_time):
                                scheduled_time = slot_time
                                break
                        if scheduled_time:
                            break
                
                if scheduled_time:
                    # Update post with scheduled time
                    await db.ai_generated_posts.update_one(
                        {"id": post.get('id')},
                        {"$set": {"scheduled_for": scheduled_time, "updated_at": datetime.utcnow()}}
                    )
                    print(f"   [SCHEDULED] Post for campaign '{campaign.get('name')}' at {scheduled_time.strftime('%Y-%m-%d %H:%M UTC')}")
                    
            except Exception as e:
                print(f"   [ERROR] Failed to schedule post: {e}")
                continue
                
    except Exception as e:
        print(f"[ERROR] Auto-scheduling failed: {e}")

async def auto_post_approved_content():
    """
    Automatically post approved content that is scheduled for now
    This runs every 5 minutes to check for scheduled posts
    Uses UTC time but respects the time slots configured in campaigns
    """
    print(f"\n{'='*60}")
    print(f"[AUTO-POST] Job Started")
    print(f"   Time: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC")
    print(f"{'='*60}\n")
    
    db = get_db()
    
    try:
        # First, auto-schedule any approved posts that don't have a time yet
        await auto_schedule_approved_posts()
        
        # Get all approved posts that are scheduled for now or earlier
        current_time = datetime.utcnow()
        
        # Check AI-generated campaign posts
        approved_posts = await db.ai_generated_posts.find({
            "status": AIGeneratedPostStatus.APPROVED,
            "scheduled_for": {"$lte": current_time}
        }).to_list(length=50)
        
        # Check manually scheduled posts from drafts
        scheduled_posts = await db.scheduled_posts.find({
            "status": "scheduled",
            "publish_time": {"$lte": current_time.isoformat()}
        }).to_list(length=50)
        
        print(f"[AI POSTS] Found {len(approved_posts)} AI posts ready to post")
        print(f"[MANUAL POSTS] Found {len(scheduled_posts)} manually scheduled posts ready to post")
        
        for post in approved_posts:
            try:
                post_id = post.get('id')
                campaign_id = post.get('campaign_id')
                org_id = post.get('org_id')
                content = post.get('content')
                
                # Get campaign info
                campaign = await db.campaigns.find_one({"id": campaign_id}, {"_id": 0})
                if not campaign:
                    print(f"   [WARNING] Campaign not found for post {post_id}")
                    continue
                
                # Check if campaign allows auto-posting
                if not campaign.get('auto_post', False):
                    print(f"   [SKIPPED] Campaign '{campaign.get('name')}' has auto-post disabled")
                    continue
                
                print(f"\n[POSTING] Campaign: {campaign.get('name')}")
                
                # Get organization's LinkedIn access token
                org = await db.organizations.find_one({"id": org_id}, {"_id": 0})
                if not org or not org.get('linkedin_access_token'):
                    print(f"   [WARNING] No LinkedIn access token for organization")
                    # Mark as failed
                    await db.ai_generated_posts.update_one(
                        {"id": post_id},
                        {
                            "$set": {
                                "status": AIGeneratedPostStatus.FAILED,
                                "updated_at": datetime.utcnow()
                            }
                        }
                    )
                    continue
                
                # Initialize LinkedIn adapter
                # Pass dummy credentials to disable mock mode since we have a real access token
                linkedin = LinkedInAdapter(client_id="from_user", client_secret="from_user")
                
                # Get author info - check if posting as organization or person
                # Try to get sub from linkedin_profile object first, then fallback to root level
                linkedin_profile = org.get('linkedin_profile', {})
                author_id = org.get('linkedin_person_urn') or linkedin_profile.get('sub') or org.get('linkedin_sub')
                is_organization = campaign.get('posting_as_organization', False)
                
                if is_organization and org.get('linkedin_organization_id'):
                    author_id = org.get('linkedin_organization_id')
                
                # Post to LinkedIn
                result = await linkedin.create_post(
                    access_token=org['linkedin_access_token'],
                    author_id=author_id,
                    content={'body': content},
                    is_organization=is_organization
                )
                
                # Check if post was successful (has an id)
                if result and result.get('id'):
                    # Update post status to POSTED
                    await db.ai_generated_posts.update_one(
                        {"id": post_id},
                        {
                            "$set": {
                                "status": AIGeneratedPostStatus.POSTED,
                                "posted_at": datetime.utcnow(),
                                "linkedin_post_id": result.get('id'),
                                "platform_url": result.get('url'),
                                "updated_at": datetime.utcnow()
                            }
                        }
                    )
                    
                    # Update campaign analytics
                    await db.campaigns.update_one(
                        {"id": campaign_id},
                        {
                            "$set": {"last_post_time": datetime.utcnow().isoformat()},
                            "$inc": {"posts_this_week": 1, "posts_this_month": 1}
                        }
                    )
                    
                    print(f"   [SUCCESS] Posted successfully!")
                    print(f"   Post ID: {result.get('id')}")
                    print(f"   URL: {result.get('url')}")
                else:
                    print(f"   [FAILED] Posting failed: No post ID returned")
                    print(f"   Result: {result}")
                    # Mark as failed
                    await db.ai_generated_posts.update_one(
                        {"id": post_id},
                        {
                            "$set": {
                                "status": AIGeneratedPostStatus.FAILED,
                                "updated_at": datetime.utcnow()
                            }
                        }
                    )
                    
            except Exception as e:
                print(f"   [ERROR] Error posting content: {e}")
                # Mark as failed
                await db.ai_generated_posts.update_one(
                    {"id": post.get('id')},
                    {
                        "$set": {
                            "status": AIGeneratedPostStatus.FAILED,
                            "updated_at": datetime.utcnow()
                        }
                    }
                )
                continue
        
        # Now process manually scheduled posts
        for post in scheduled_posts:
            try:
                post_id = post.get('id')
                org_id = post.get('org_id')
                draft_id = post.get('draft_id')
                
                # Get draft content
                draft = await db.drafts.find_one({"id": draft_id}, {"_id": 0})
                if not draft:
                    print(f"   [WARNING] Draft not found for post {post_id}")
                    continue
                
                content_body = draft.get('content', {}).get('body', '')
                if not content_body:
                    print(f"   [WARNING] No content in draft {draft_id}")
                    continue
                
                print(f"\n[POSTING] Manual Post: {post_id[:20]}...")
                
                # Get organization's LinkedIn access token
                org = await db.organizations.find_one({"id": org_id}, {"_id": 0})
                if not org or not org.get('linkedin_access_token'):
                    print(f"   [WARNING] No LinkedIn access token for organization")
                    await db.scheduled_posts.update_one(
                        {"id": post_id},
                        {"$set": {"status": "failed", "updated_at": datetime.utcnow()}}
                    )
                    continue
                
                # Initialize LinkedIn adapter
                # Pass dummy credentials to disable mock mode since we have a real access token
                linkedin = LinkedInAdapter(client_id="from_user", client_secret="from_user")
                
                # Get author info
                # Try to get sub from linkedin_profile object first, then fallback to root level
                linkedin_profile = org.get('linkedin_profile', {})
                author_id = org.get('linkedin_person_urn') or linkedin_profile.get('sub') or org.get('linkedin_sub')
                is_organization = post.get('posting_as_organization', False)
                
                if is_organization and org.get('linkedin_organization_id'):
                    author_id = org.get('linkedin_organization_id')
                
                # Get image if exists
                image_url = None
                assets = draft.get('assets', [])
                if assets and len(assets) > 0:
                    image_url = assets[0].get('url')
                
                # Post to LinkedIn
                result = await linkedin.create_post(
                    access_token=org['linkedin_access_token'],
                    author_id=author_id,
                    content={'body': content_body},
                    is_organization=is_organization
                )
                
                # Check if post was successful (has an id)
                if result and result.get('id'):
                    # Update post status to PUBLISHED
                    await db.scheduled_posts.update_one(
                        {"id": post_id},
                        {
                            "$set": {
                                "status": "published",
                                "published_at": datetime.utcnow(),
                                "linkedin_post_id": result.get('id'),
                                "platform_url": result.get('url'),
                                "updated_at": datetime.utcnow()
                            }
                        }
                    )
                    print(f"   [SUCCESS] Posted successfully!")
                    print(f"   Post ID: {result.get('id')}")
                    print(f"   URL: {result.get('url')}")
                else:
                    print(f"   [FAILED] Posting failed: No post ID returned")
                    print(f"   Result: {result}")
                    await db.scheduled_posts.update_one(
                        {"id": post_id},
                        {
                            "$set": {
                                "status": "failed",
                                "error": result.get('error'),
                                "updated_at": datetime.utcnow()
                            }
                        }
                    )
                    
            except Exception as e:
                print(f"   [ERROR] Error posting manual content: {e}")
                await db.scheduled_posts.update_one(
                    {"id": post.get('id')},
                    {"$set": {"status": "failed", "updated_at": datetime.utcnow()}}
                )
                continue
        
        print(f"\n{'='*60}")
        print(f"[AUTO-POST] Job Completed")
        print(f"{'='*60}\n")
        
    except Exception as e:
        print(f"[ERROR] Auto-posting job failed: {e}")
        print(f"{'='*60}\n")

def start_scheduler():
    """Initialize and start the background scheduler"""
    global scheduler
    
    if scheduler is not None:
        print("⚠️  WARNING: Scheduler already running")
        return
    
    try:
        print(f"\n{'='*60}")
        print(f"🚀 Starting Background Scheduler")
        print(f"{'='*60}\n")
        
        scheduler = AsyncIOScheduler()
        
        # Schedule content generation job - runs every 5 minutes for fast response
        # (campaigns with longer frequencies will naturally generate less often based on their pending post count)
        scheduler.add_job(
            generate_content_for_active_campaigns,
            CronTrigger(minute='*/5'),  # Every 5 minutes
            id='content_generation',
            name='Auto-generate content for active campaigns',
            replace_existing=True
        )
        print("✅ SCHEDULED: Content Generation (Every 5 minutes)")
        
        # Schedule auto-posting job - runs every 5 minutes for fast testing
        scheduler.add_job(
            auto_post_approved_content,
            CronTrigger(minute='*/5'),  # Every 5 minutes
            id='auto_posting',
            name='Auto-post approved content',
            replace_existing=True
        )
        print("✅ SCHEDULED: Auto-Posting (Every 5 minutes)")
        
        # Start scheduler in non-blocking mode
        scheduler.start()
        
        print(f"\n{'='*60}")
        print(f"✅ Scheduler Started Successfully")
        print(f"{'='*60}\n")
        
    except Exception as e:
        print(f"\n{'='*60}")
        print(f"❌ ERROR: Failed to start scheduler")
        print(f"   {str(e)}")
        print(f"   Server will continue without scheduler")
        print(f"{'='*60}\n")
        scheduler = None

def stop_scheduler():
    """Stop the background scheduler"""
    global scheduler
    
    if scheduler is None:
        print("WARNING: Scheduler not running")
        return
    
    print("\nStopping scheduler...")
    scheduler.shutdown()
    scheduler = None
    print("Scheduler stopped\n")

# Manual trigger functions for testing/on-demand execution
async def trigger_content_generation():
    """Manually trigger content generation"""
    await generate_content_for_active_campaigns()

async def trigger_auto_posting():
    """Manually trigger auto-posting"""
    await auto_post_approved_content()



