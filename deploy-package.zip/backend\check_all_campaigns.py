import asyncio
from motor.motor_asyncio import AsyncIOMotorClient
from dotenv import load_dotenv
import os
from datetime import datetime

load_dotenv()

async def check_all_campaigns():
    client = AsyncIOMotorClient(os.environ.get('MONGO_URL', 'mongodb://localhost:27017'))
    db = client[os.environ.get('DB_NAME', 'linkedin_pilot')]
    
    # Get all campaigns
    campaigns = await db.campaigns.find({}, {'_id': 0}).to_list(length=None)
    
    print("\n" + "="*80)
    print(f"TOTAL CAMPAIGNS: {len(campaigns)}")
    print("="*80)
    
    for i, campaign in enumerate(campaigns, 1):
        print(f"\n[{i}] Campaign: {campaign.get('name')}")
        print(f"    ID: {campaign.get('id')}")
        print(f"    Org ID: {campaign.get('org_id')}")
        print(f"    Status: {campaign.get('status')}")
        print(f"    Auto-post: {campaign.get('auto_post', False)}")
        print(f"    Frequency: {campaign.get('posting_schedule', {}).get('frequency')}")
        print(f"    Time slots: {campaign.get('posting_schedule', {}).get('time_slots')}")
        print(f"    Last generation: {campaign.get('last_generation_time')}")
        print(f"    Next generation: {campaign.get('next_generation_time')}")
        print(f"    Total posts: {campaign.get('total_posts', 0)}")
        
        # Get organization name
        org = await db.organizations.find_one({'id': campaign.get('org_id')}, {'_id': 0})
        if org:
            print(f"    Organization: {org.get('name')}")
        
        # Count AI posts for this campaign
        ai_post_count = await db.ai_generated_posts.count_documents({'campaign_id': campaign.get('id')})
        print(f"    AI Posts: {ai_post_count}")
        
        # Get latest AI post
        latest_post = await db.ai_generated_posts.find_one(
            {'campaign_id': campaign.get('id')},
            {'_id': 0},
            sort=[('created_at', -1)]
        )
        if latest_post:
            print(f"    Latest post: {latest_post.get('created_at')} - Status: {latest_post.get('status')}")
    
    print("\n" + "="*80)
    
    # Get all organizations
    orgs = await db.organizations.find({}, {'_id': 0}).to_list(length=None)
    print(f"\nORGANIZATIONS: {len(orgs)}")
    print("-"*80)
    for org in orgs:
        print(f"  - {org.get('name')} (ID: {org.get('id')})")
    
    client.close()

if __name__ == "__main__":
    asyncio.run(check_all_campaigns())
