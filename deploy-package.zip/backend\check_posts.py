"""
Utility script to check posts in the database
Useful for debugging and verifying post data
"""

import asyncio
import os
from motor.motor_asyncio import AsyncIOMotorClient
from dotenv import load_dotenv
from datetime import datetime

load_dotenv()

async def check_posts():
    """Check and display posts from the database"""
    
    # Connect to MongoDB
    client = AsyncIOMotorClient(os.environ['MONGO_URL'])
    db = client[os.environ['DB_NAME']]
    
    print("=" * 80)
    print("CHECKING POSTS IN DATABASE")
    print("=" * 80)
    
    # Get all posts
    posts = await db.posts.find({}).to_list(length=None)
    
    print(f"\nTotal posts found: {len(posts)}")
    print("-" * 80)
    
    for i, post in enumerate(posts, 1):
        print(f"\n[{i}] Post ID: {post.get('id', 'N/A')}")
        print(f"    Organization: {post.get('org_id', 'N/A')}")
        print(f"    Status: {post.get('status', 'N/A')}")
        print(f"    Content: {post.get('content', 'N/A')[:100]}...")
        print(f"    Created: {post.get('created_at', 'N/A')}")
        
        if post.get('scheduled_time'):
            print(f"    Scheduled: {post.get('scheduled_time')}")
        
        if post.get('posted_at'):
            print(f"    Posted: {post.get('posted_at')}")
        
        if post.get('linkedin_post_id'):
            print(f"    LinkedIn ID: {post.get('linkedin_post_id')}")
    
    # Get scheduled posts
    print("\n" + "=" * 80)
    print("SCHEDULED POSTS")
    print("=" * 80)
    
    scheduled = await db.scheduled_posts.find({}).to_list(length=None)
    print(f"\nTotal scheduled posts: {len(scheduled)}")
    
    for i, post in enumerate(scheduled, 1):
        print(f"\n[{i}] Scheduled Post ID: {post.get('id', 'N/A')}")
        print(f"    Organization: {post.get('org_id', 'N/A')}")
        print(f"    Status: {post.get('status', 'N/A')}")
        print(f"    Scheduled for: {post.get('scheduled_time', 'N/A')}")
        print(f"    Content: {post.get('content', 'N/A')[:100]}...")
    
    # Get AI-generated posts
    print("\n" + "=" * 80)
    print("AI-GENERATED POSTS (REVIEW QUEUE)")
    print("=" * 80)
    
    ai_posts = await db.ai_generated_posts.find({}).to_list(length=None)
    print(f"\nTotal AI-generated posts: {len(ai_posts)}")
    
    for i, post in enumerate(ai_posts, 1):
        print(f"\n[{i}] AI Post ID: {post.get('id', 'N/A')}")
        print(f"    Campaign: {post.get('campaign_id', 'N/A')}")
        print(f"    Status: {post.get('status', 'N/A')}")
        print(f"    Content: {post.get('content', 'N/A')[:100]}...")
        print(f"    Created: {post.get('created_at', 'N/A')}")
    
    print("\n" + "=" * 80)
    print("CHECK COMPLETE")
    print("=" * 80)
    
    client.close()

if __name__ == "__main__":
    asyncio.run(check_posts())
