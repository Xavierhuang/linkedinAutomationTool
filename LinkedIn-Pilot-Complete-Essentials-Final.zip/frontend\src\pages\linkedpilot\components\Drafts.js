import BeeBotDraftsView from './BeeBotDraftsView';

export default BeeBotDraftsView;