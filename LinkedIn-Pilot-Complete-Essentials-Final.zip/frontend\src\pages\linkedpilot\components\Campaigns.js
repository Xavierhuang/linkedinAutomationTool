import CampaignsView from './CampaignsView';

export default CampaignsView;