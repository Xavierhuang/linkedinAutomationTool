import PostsView from './PostsView';

export default PostsView;