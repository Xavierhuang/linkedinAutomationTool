import InboxView from './InboxView';

export default InboxView;