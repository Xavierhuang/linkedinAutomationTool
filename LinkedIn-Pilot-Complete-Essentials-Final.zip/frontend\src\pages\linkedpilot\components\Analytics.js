import AnalyticsView from './AnalyticsView';

export default AnalyticsView;